<?php
?>
    <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset("style/public-nav-header.css")); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset("style/public-footer.css")); ?>"rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset("style/public-modal-sign-up.css")); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset("style/public-home-body.css")); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset("style/shopping-list-flyer.css")); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset("style/public-side-nav.css")); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link href="<?php echo e(asset('image/favicon.png')); ?>" rel="shortcut icon" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="<?php echo e(asset('script/public-sign-up.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('script/public-browse-flyer.js')); ?>" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <title>Klipp</title>
</head>
<body class="mybody">
<header>
    <div class="header">
        <nav class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar3">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url("/home")); ?>"><img
                            alt="Klipp logo" src="<?php echo e(asset("image/public-logo.png")); ?>"/></a>
                </div>
                <div id="navbar3" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <!--                        <li class="active"><a href="#">Home</a></li>-->
                        <li><a href="<?php echo e(url('/shoppingList')); ?>">Shopping List</a></li>
                        <li><a class="" href="#signup" data-toggle="modal" data-target=".log-sign">
                                <i class="fa fa-user-circle-o"></i> Sign Up</a></li>
                        <li><a href="">Flyers</a></li>
                        <li><a href="<?php echo e(url("/flyer")); ?>">Search</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">About Klipp <span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">How to use</a></li>
                                <li><a href="ContactUs.php">Contact Us</a></li>
                                <li class="divider"></li>
                                <li class="dropdown-header">Clients</li>
                                <li><a href="clientLogin.php">Client login</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
            <!--/.container-fluid -->
        </nav>
    </div>
</header>

<!-- Modal -->
<div class="modal fade bs-modal-sm log-sign" id="myModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">

            <div class="bs-example bs-example-tabs">
                <ul id="myTab" class="nav nav-tabs">
                    <li id="tab1" class=" active tab-style login-shadow "><a href="#signin" data-toggle="tab">Log In</a></li>
                    <li id="tab2" class=" tab-style "><a href="#signup" data-toggle="tab">Sign Up</a></li>

                </ul>
            </div>
            <div class="modal-body">
                <div id="myTabContent" class="tab-content">

                    <div class="tab-pane fade active in" id="signin">
                        <form class="form-horizontal">
                            <fieldset>
                                <!-- Sign In Form -->
                                <!-- Text input-->

                                <div class="group">
                                    <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                    <label class="label" for="date">Email address</label></div>


                                <!-- Password input-->
                                <div class="group">
                                    <input required="" class="input" type="password"><span class="highlight"></span><span class="bar"></span>
                                    <label class="label" for="date">Password</label>
                                </div>
                                <em>minimum 6 characters</em>

                                <div class="forgot-link">
                                    <a href="#forgot" data-toggle="modal" data-target="#forgot-password"> I forgot my password</a>
                                </div>


                                <!-- Button -->
                                <div class="control-group">
                                    <label class="control-label" for="signin"></label>
                                    <div class="controls">
                                        <button id="signin" name="signin" class="btn btn-primary btn-block">Log In</button>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>


                    <div class="tab-pane fade" id="signup">
                        <form class="form-horizontal">
                            <fieldset>
                                <!-- Sign Up Form -->
                                <!-- Text input-->
                                <div class="group">
                                    <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                    <label class="label" for="date">First Name</label></div>

                                <!-- Text input-->
                                <div class="group">
                                    <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                    <label class="label" for="date">Last Name</label></div>

                                <!-- Password input-->
                                <div class="group">
                                    <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                    <label class="label" for="date">Email</label></div>

                                <!-- Text input-->
                                <div class="group">
                                    <input required="" class="input" type="password"><span class="highlight"></span><span class="bar"></span>
                                    <label class="label" for="date">Password</label></div>
                                <em>1-8 Characters</em>

                                <div class="group2">
                                    <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                    <label class="label" for="date">Country</label></div>



                                <!-- Button -->
                                <div class="control-group">
                                    <label class="control-label" for="confirmsignup"></label>
                                    <div class="controls">
                                        <button id="confirmsignup" name="confirmsignup" class="btn btn-primary btn-block">Sign Up</button>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>



<!--modal2-->

<div class="modal fade bs-modal-sm" id="forgot-password" tabindex="0" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Password will be sent to your email</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal">
                    <fieldset>
                        <div class="group">
                            <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                            <label class="label" for="date">Email address</label></div>


                        <div class="control-group">
                            <label class="control-label" for="forpassword"></label>
                            <div class="controls">
                                <button id="forpasswodr" name="forpassword" class="btn btn-primary btn-block">Send</button>
                            </div>
                        </div>
                    </fieldset>
                </form>

            </div>
        </div>

    </div>
</div>
<div id="wrapper">
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <li class="sidebar-brand">
                <div class="sidenav">
                    <div style="background: #3f51b5;">
                        <br>
                        <span style="color:white;">&nbsp;&nbsp;Flyers for M9W4R3
							<a style="font-size:11px;"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;(Change Location)</a>
						</span>
                    </div>
                    <a href="#favorites"><i class="fa fa-star" aria-hidden="true"></i>&nbsp;Favorites</a>
                    <a href="#flyers"><i class="fa fa-picture-o" aria-hidden="true"></i>&nbsp;Flyers</a>
                </div>
            </li>
            <hr>
            <?php if(Session::has('ProductCategories')): ?>
            <?php $__currentLoopData = Session::get('ProductCategories'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="#"><?php echo e($value['Category']); ?> (<?php echo e($value['Count']); ?>)</a>
            </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php echo e(Session()->forget('ProductCategories')); ?>

        </ul>
    </div>
<section>
    <?php echo $__env->yieldContent('content-after-side-nav'); ?>
</section>
</div>
</body>
</html>

<?php /**PATH C:\XAMPP\htdocs\GitHub\Project feature one - Phase three\blog\resources\views/layouts/public-side-nav.blade.php ENDPATH**/ ?>