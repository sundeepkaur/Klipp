<?php $__env->startSection('content-after-side-nav'); ?>
<!-- Page Content -->
    <div id="page-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="col-md-4" style="display:inline-flex">
                        <form action="<?php echo e(url('/shoppingList/create')); ?>" method="get" role="search">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group">
                                <input type="text" class="form-control" name="item-name" placeholder="Search items">
                                <div class="input-group-btn">
                                    <button class="btn btn-default" type="submit">
                                        <i class="glyphicon glyphicon-search" style="font-size:15px; color: #3F51B5;"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <button class="btn btn-default" id="menu-toggle" onclick="myToogleFunction()">Show menu</button>
                    <div class="row">
                        <div class="project-content">
                            <div class="col-xs-6 col-sm-6">
                                <div id="shopping-list">
                                    <div class="table-responsive">
                                        <h4>MY SHOPPING LIST</h4>
                                        <form action="/shoppingList" method="post" name="shoppingList">
                                            <?php echo e(csrf_field()); ?>

                                            <table class="table">
                                                <?php if(Session::has('ShoppingListItem')): ?>
                                                    <?php $__currentLoopData = Session::get('ShoppingListItem'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($value['Product Name']); ?></td>
                                                            <td>$</td>
                                                            <td><input type="submit" name="fav" value="Favourite" class="btn1">
                                                                <input type="submit" name="remove" value="Remove" class="btn"></td>
                                                            <input type="hidden"  name="product-name" value="<?php echo e($value['Product Name']); ?>">
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                    <tr>
                                                        <td><h4>Miscellaneous Cost</h4></td>
                                                        <td><input type="text" placeholder="Amount"></td>
                                                        <td>Not mandatory</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2"><h4>Add mode of commute</h4></td>
                                                        <td><a href="">location</a> </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="color: #009FB7"><h4>Total Amount</h4></td>
                                                        <td><input type="text" placeholder="Total Amount"></td>
                                                        <td><input type="submit" value="Get Total" name="total"></td>
                                                    </tr>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                                <div class="row">
                                    <div id="clipped-flyer">
                                        <div class="row text-center text-lg-left">
                                            <h4> MY CLIPPINGS</h4>
                                            <div class="col-lg-3 col-md-4 col-6">
                                                <a href="#" class="d-block mb-4 h-100">
                                                    <img class="img-fluid img-thumbnail"
                                                         src="https://source.unsplash.com/pWkk7iiCoDM/400x300" alt="">
                                                </a>
                                            </div>
                                            <div class="col-lg-3 col-md-4 col-6">
                                                <a href="#" class="d-block mb-4 h-100">
                                                    <img class="img-fluid img-thumbnail"
                                                         src="https://source.unsplash.com/aob0ukAYfuI/400x300" alt="">
                                                </a>
                                            </div>
                                            <div class="col-lg-3 col-md-4 col-6">
                                                <a href="#" class="d-block mb-4 h-100">
                                                    <img class="img-fluid img-thumbnail"
                                                         src="https://source.unsplash.com/EUfxH-pze7s/400x300" alt="">
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6">
                                <div  id="related-flyer">
                                    <div class="row text-center text-lg-left overflow-auto ">
                                        <h4>RELATED FLYERS</h4>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/pWkk7iiCoDM/400x300" alt="">
                                            </a>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/aob0ukAYfuI/400x300" alt="">
                                            </a>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/EUfxH-pze7s/400x300" alt="">
                                            </a>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/pWkk7iiCoDM/400x300" alt="">
                                            </a>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/aob0ukAYfuI/400x300" alt="">
                                            </a>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/EUfxH-pze7s/400x300" alt="">
                                            </a>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/pWkk7iiCoDM/400x300" alt="">
                                            </a>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/aob0ukAYfuI/400x300" alt="">
                                            </a>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail"
                                                     src="https://source.unsplash.com/EUfxH-pze7s/400x300" alt="">
                                            </a>
                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!--</div>-->








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public-side-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\GitHub\Project feature one - Phase three\blog\resources\views/public-interface/public-shopping-list.blade.php ENDPATH**/ ?>