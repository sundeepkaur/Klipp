<?php $__env->startSection('content-after-side-nav'); ?>
    <div id="page-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="col-md-4" style="display:inline-flex">
                        <form action="<?php echo e(url('/flyer/create')); ?>" method="get" role="search">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group">
                                <input type="text" class="form-control" name="item-name" placeholder="Search items">
                                <div class="input-group-btn">
                                    <button class="btn btn-default" type="submit">
                                        <i class="glyphicon glyphicon-search" style="font-size:15px; color: #3F51B5;"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                        <?php if(isset($_POST['item-entry-error'])): ?>
                            <?php
                            echo "<p style=color:red"." >".$_POST['item-entry-error']."</p>";
                            ?>
                        <?php endif; ?>
                    </div>
                    <button class="btn btn-default" id="menu-toggle" onclick="myToogleFunction()">Show menu</button>
                    <div class="row">
                        <div id="clipped-flyer">
                            <div class="row text-center text-lg-left">
                                
                                <?php if(Session::has('BrowseItems')): ?>
                                    <h4>RELATED FLYERS</h4>
                                    <?php $__currentLoopData = Session::get('BrowseItems'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $value['Flyers Images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <form id="myForm">
                                                <div class="col-lg-3 col-md-4 col-6">
                                                    <a href="#" class="d-block mb-4 h-100">
                                                        <img class="img-fluid img-thumbnail"
                                                             src="<?php echo e(asset($flyer)); ?>" id="favourite_image" alt="">
                                                        <button class="btn btn-primary" id="favourite_image">Submit</button>
                                                    </a>
                                                </div>
                                            </form>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if(Session::has('SideSearchNavResults')): ?>
                                    <h4> MY CLIPPINGS</h4>
                                    <?php $__currentLoopData = Session::get('SideSearchNavResults'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $value['Flyers Images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <form id="myForm">
                                                <div class="col-lg-3 col-md-4 col-6">
                                                    <a href="#" class="d-block mb-4 h-100">
                                                        <img id="flyer_image" class="img-fluid img-thumbnail"
                                                             src="<?php echo e(asset($flyer)); ?>"  alt="">
                                                        <button class="btn btn-primary" id="favourite_image">Submit</button>
                                                    </a>
                                                </div>
                                            </form>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        jQuery(document).ready(function(){
            jQuery('#favourite_image').click(function(e){
                e.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                jQuery.ajax({
                    url: "<?php echo e(url('/flyers/favourites')); ?>",
                    method: 'post',
                    data: {
                        flyer_image: jQuery('#flyer_image').val(),
                    },
                    success: function(result){
                        console.log(result);
                    }});
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public-side-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project feature one - Phase three\blog\resources\views/public-interface/public-search-flyer.blade.php ENDPATH**/ ?>