<?php $__env->startSection('content'); ?>
    <div id="wrapper">
<div id="sidebar-wrapper">
    <ul class="sidebar-nav">
        <li class="sidebar-brand">
            <div class="sidenav">
                <div style="background: #3f51b5;">
                    <br>
                    <span style="color:white;">&nbsp;&nbsp;Flyers for M9W4R3
							<a style="font-size:11px;"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;(Change Location)</a>
						</span>
                </div>
                <a href="#favorites"><i class="fa fa-star" aria-hidden="true"></i>&nbsp;Favorites</a>
                <a href="#flyers"><i class="fa fa-picture-o" aria-hidden="true"></i>&nbsp;Flyers</a>
                <a href="#coupons"><i class="fa fa-usd" aria-hidden="true"></i>&nbsp;Coupons</a>
            </div>
        </li>
        <hr>
        <li>
            <a href="#">Produce</a>
        </li>
        <li>
            <a href="#">Dairy</a>
        </li>
        <li>
            <a href="#">Meat</a>
        </li>
        <li>
            <a href="#">Dry food</a>
        </li>
        <li>
            <a href="#">Electronics</a>
        </li>
        <li>
            <a href="#">Stationary</a>
        </li>
        <li>
            <a href="#">Seasonal</a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<section>
    <?php echo $__env->yieldContent('shopping-list'); ?>
</section>
    </div>

<?php echo $__env->make('layouts.home-nav-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\GitHub\Project feature one - Phase three\blog\resources\views/public-interface/public-side-nav.blade.php ENDPATH**/ ?>