<?php $__env->startSection('content-after-side-nav'); ?>
    <!-- Page Content -->
    <div id="page-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="col-md-4" style="display:inline-flex">
                        <form action="<?php echo e(url('/shoppingList/create')); ?>" method="get" role="search">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group">
                                <input type="text" class="form-control" name="item-name" placeholder="Search items">
                                <div class="input-group-btn">
                                    <button class="btn btn-default" type="submit">
                                        <i class="glyphicon glyphicon-search" style="font-size:15px; color: #3F51B5;"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <button class="btn btn-default" id="menu-toggle" onclick="myToogleFunction()">Show menu</button>
                    <div class="row">
                        <div class="project-content">
                            <div class="col-xs-6 col-sm-6">
                                <div id="shopping-list">
                                    <div class="table-responsive">
                                        <h4>MY SHOPPING LIST</h4>
                                        <table id="shoppingListTable" class="table">
                                            
                                            <form method="post" action="<?php echo e(url('/shoppingList/calculate')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <?php if(Session::has('ShoppingListItem')): ?>
                                                    <?php $__currentLoopData = Session::get('ShoppingListItem'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr id="<?php echo e($value['Product Name']); ?>">
                                                            <td><?php echo e($value['Product Name']); ?></td>
                                                            <td>$<?php echo e($value['Current Price']); ?></td>
                                                            <td><input type="submit" name="fav" value="Favourite" class="btn">
                                                                <input type="submit" name="remove" id="remove" value="Remove" class="btn"></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <tr>
                                                    <td><h4>Miscellaneous Cost</h4></td>
                                                    <td><input type="text" value="<?php
                                                        if (isset($_POST['miscellaneous-cost']))
                                                            echo $_POST['miscellaneous-cost']?> "
                                                               name="miscellaneous-cost" placeholder="Amount"></td>
                                                    <td>Not mandatory</td>
                                                    <?php if(isset($_POST['miscellaneous-cost-error'])): ?>
                                                        <?php
                                                        echo "<p style=color:red"." >".$_POST['miscellaneous-cost-error']."</p>";
                                                        ?>
                                                    <?php endif; ?>
                                                </tr>
                                                <tr>
                                                    <td style="color: #009FB7"><h4>Total Amount</h4></td>
                                                    <?php if(Session::has('ShoppingListTotal')): ?>
                                                        <?php $__currentLoopData = Session::get('ShoppingListTotal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td><input type="text"  value="<?php echo e($value['Total']); ?>" placeholder="Total Amount"></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    <td><input type="submit" value="Get Total" name="total"></td>
                                                </tr>
                                            </form>
                                        </table>
                                    </div>
                                </div>
                                <div class="row">
                                    <div id="clipped-flyer">
                                        <div class="row text-center text-lg-left">
                                            <h4> MY CLIPPINGS</h4>
                                            <div id="DisplayImage">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6">
                                <div  id="related-flyer">
                                    <div class="row text-center text-lg-left overflow-auto ">
                                        <h4>RELATED FLYERS</h4>
                                        <form id="flyer-clicked">
                                            <?php if(Session::has('Flyers')): ?>
                                                <?php $__currentLoopData = Session::get('Flyers'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $value['Flyer Images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-lg-3 col-md-4 col-6">
                                                            <input  id="<?php echo e($flyer); ?>" type="image" name="submit" value="<?php echo e($flyer); ?>"
                                                                    src="<?php echo e(asset($flyer)); ?>" class="image-name img-fluid img-thumbnail" >
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </form>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!--</div>-->
    <script src="<?php echo e(asset('script/public-shopping-list.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public-side-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project feature one - Phase three\blog\resources\views/public-interface/public-shopping-list.blade.php ENDPATH**/ ?>